from flask import Flask, render_template, make_response
from flask_mysql_connector import MySQL
import csv
import io

app = Flask(__name__)

# Configure MySQL connection
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DATABASE'] = 'hr_analytics'

mysql = MySQL(app)

@app.route('/')
def experience_by_location():
    cursor = mysql.connection.cursor()

    query = '''
        SELECT 
            CASE 
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 0 AND 1 THEN '0–1'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 1 AND 2 THEN '1–2'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 2 AND 5 THEN '2–5'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 5 AND 10 THEN '5–10'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) > 10 THEN '10+'
                ELSE 'Unknown' 
            END AS experience_range,
            Location,
            COUNT(*) AS employee_count
        FROM Employee_data
        GROUP BY experience_range, Location
        ORDER BY experience_range, Location;
    '''

    cursor.execute(query)
    results = cursor.fetchall()

    columns = ['experience_range', 'Location', 'employee_count']
    data = [dict(zip(columns, row)) for row in results]

    cursor.close()
    return render_template('case2.html', data=data)


@app.route('/export-experience')
def export_experience_csv():
    cursor = mysql.connection.cursor()

    query = '''
        SELECT 
            CASE 
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 0 AND 1 THEN '0–1'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 1 AND 2 THEN '1–2'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 2 AND 5 THEN '2–5'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) BETWEEN 5 AND 10 THEN '5–10'
                WHEN CAST(Years_of_Experience AS DECIMAL(4,2)) > 10 THEN '10+'
                ELSE 'Unknown' 
            END AS experience_range,
            Location,
            COUNT(*) AS employee_count
        FROM Employee_data
        GROUP BY experience_range, Location
        ORDER BY experience_range, Location;
    '''

    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Experience Range', 'Location', 'Employee Count'])

    for row in results:
        writer.writerow(row)

    response = make_response(output.getvalue())
    response.headers['Content-Disposition'] = 'attachment; filename=experience_by_location.csv'
    response.headers['Content-Type'] = 'text/csv'

    return response


if __name__ == '__main__':
    app.run(port=5001, debug=True)
