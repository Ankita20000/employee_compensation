from flask import Flask, render_template, request, send_file
from flask_mysql_connector import MySQL
import json
import csv
import io

app = Flask(__name__)

# Database config
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_DATABASE'] = 'hr_analytics'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

@app.route('/', methods=['GET', 'POST'])
def index():
    location_filter = request.form.get('location')
    role_filter = request.form.get('role')
    include_inactive = request.form.get('include_inactive')

    cursor = mysql.connection.cursor(dictionary=True)

    # Filters
    conditions = []
    values = []

    if location_filter:
        conditions.append("Location LIKE %s")
        values.append(f"%{location_filter}%")

    if role_filter:
        conditions.append("Role LIKE %s")
        values.append(f"%{role_filter}%")

    if not include_inactive:
        conditions.append("Active = 'Y'")

    where_clause = " AND ".join(conditions)
    query = "SELECT * FROM Employee_data"
    if where_clause:
        query += f" WHERE {where_clause}"

    cursor.execute(query, tuple(values))
    employees = cursor.fetchall()

    # Average compensation
    avg_comp = None
    if location_filter:
        avg_query = "SELECT AVG(CurrentComp) as avg_comp FROM Employee_data WHERE Location LIKE %s"
        if not include_inactive:
            avg_query += " AND Active = 'Y'"
        cursor.execute(avg_query, (f"%{location_filter}%",))
        avg_result = cursor.fetchone()
        if avg_result and avg_result['avg_comp'] is not None:
            avg_comp = float(avg_result['avg_comp'])

    # Bar chart: AVG compensation per location
    chart_query = "SELECT Location, AVG(CurrentComp) as avg_comp FROM Employee_data"
    if not include_inactive:
        chart_query += " WHERE Active = 'Y'"
    chart_query += " GROUP BY Location"

    cursor.execute(chart_query)
    chart_data = cursor.fetchall()

    for row in chart_data:
        row['avg_comp'] = float(row['avg_comp'])

    cursor.close()

    return render_template(
        'case1.html',
        employees=employees,
        avg_comp=avg_comp,
        chart_data=json.dumps(chart_data),
        selected_location=location_filter,
        selected_role=role_filter,
        include_inactive=include_inactive
    )

@app.route('/export', methods=['POST'])
def export_csv():
    employees = []

    global_increment = float(request.form.get("global_increment", 0))
    
    for key in request.form:
        if key.startswith("custom_"):
            parts = key.split("_")
            name = parts[1]
            location = parts[2]
            increment_percent = float(request.form[key])
            current_comp = float(request.form.get(f"current_{name}_{location}", 0))
            new_comp = current_comp * (1 + increment_percent / 100)
            employees.append({
                "Name": name,
                "Location": location,
                "CurrentComp": current_comp,
                "IncrementPercent": increment_percent,
                "NewComp": round(new_comp, 2)
            })

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["Name", "Location", "CurrentComp", "IncrementPercent", "NewComp"])
    writer.writeheader()
    writer.writerows(employees)

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                     as_attachment=True, download_name='compensation_export.csv')


if __name__ == '__main__':
    app.run(debug=True)
