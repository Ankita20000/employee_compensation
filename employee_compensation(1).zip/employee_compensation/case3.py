from flask import Flask, render_template, request, send_file
import mysql.connector
import csv
import io

app = Flask(__name__)

# MySQL database connection
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='root',
    database='hr_analytics'
)
cursor = conn.cursor()

def get_active_employees():
    cursor.execute("SELECT Name, Location, CurrentComp FROM Employee_data WHERE Active = 'Y'")
    data = cursor.fetchall()
    employees = []
    for row in data:
        name, location, current_comp = row
        employees.append({
            'Name': name,
            'Location': location,
            'CurrentComp': current_comp,
            'IncrementPercent': 0,
            'NewComp': None
        })
    return employees

def apply_increments(employees, global_increment, custom_increments):
    for emp in employees:
        custom_key = f"{emp['Name']}_{emp['Location']}"
        increment = custom_increments.get(custom_key, global_increment)
        emp['IncrementPercent'] = increment
        emp['NewComp'] = round(emp['CurrentComp'] + (emp['CurrentComp'] * increment / 100), 2)
    return employees

@app.route('/', methods=['GET', 'POST'])
def simulate_increment():
    employees = get_active_employees()

    if request.method == 'POST':
        global_increment = float(request.form.get('global_increment', 0))
        custom_increments = {
            key.replace('custom_', ''): float(request.form[key])
            for key in request.form if key.startswith('custom_')
        }

        employees = apply_increments(employees, global_increment, custom_increments)

    return render_template('case3.html', employees=employees)

@app.route('/export', methods=['POST'])
def export_csv():
    employees = get_active_employees()
    global_increment = float(request.form.get('global_increment', 0))

    custom_increments = {
        key.replace('custom_', ''): float(request.form[key])
        for key in request.form if key.startswith('custom_')
    }

    employees = apply_increments(employees, global_increment, custom_increments)

    # Create CSV in memory
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Name', 'Location', 'CurrentComp', 'IncrementPercent', 'NewComp'])

    for emp in employees:
        writer.writerow([emp['Name'], emp['Location'], emp['CurrentComp'], emp['IncrementPercent'], emp['NewComp']])

    output.seek(0)

    return send_file(
        io.BytesIO(output.getvalue().encode('utf-8')),
        mimetype='text/csv',
        as_attachment=True,
        download_name='increment_results.csv'
    )

if __name__ == '__main__':
    app.run(port=5002, debug=True)
