import os

class Config:
    MYSQL_HOST = 'localhost'  # Change this if using a different DB host
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'root'
    MYSQL_DB = 'hr_analytics'
